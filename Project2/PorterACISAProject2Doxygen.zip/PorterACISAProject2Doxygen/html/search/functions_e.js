var searchData=
[
  ['_7eboard_0',['~Board',['../class_board.html#af73f45730119a1fd8f6670f53f959e68',1,'Board']]],
  ['_7ecandyc_1',['~Candyc',['../class_candyc.html#aa9f48577e0cbb62858b1a0d71ef66e89',1,'Candyc']]],
  ['_7egame_2',['~Game',['../class_game.html#ae3d112ca6e0e55150d2fdbc704474530',1,'Game']]],
  ['_7eplayers_3',['~Players',['../class_players.html#a550b03902064fa337ccf9f9f67b01d88',1,'Players']]]
];
