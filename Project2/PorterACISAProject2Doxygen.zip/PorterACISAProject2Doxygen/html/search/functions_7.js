var searchData=
[
  ['ifempty_0',['ifEmpty',['../class_deck.html#a5397a51f195af89762b52719a4c4cb83',1,'Deck']]],
  ['ifspecialcard_1',['ifSpecialCard',['../class_board.html#a2af0a5e6a1e5a9c1ed15557d738a0411',1,'Board']]],
  ['initgame_2',['initGame',['../class_game.html#a8abdf6e8b4c45c2c6b40f728fce376c8',1,'Game']]]
];
