var searchData=
[
  ['flavor_5f_0',['flavor_',['../class_candy.html#a883f362161ffffe88ac685798b4e0355',1,'Candy']]]
];
