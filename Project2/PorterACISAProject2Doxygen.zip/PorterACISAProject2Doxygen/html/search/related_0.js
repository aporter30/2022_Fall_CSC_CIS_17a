var searchData=
[
  ['operator_3c_3c_0',['operator&lt;&lt;',['../class_candyc.html#a5b8ce73195d99372023eb3814ea0529a',1,'Candyc']]]
];
