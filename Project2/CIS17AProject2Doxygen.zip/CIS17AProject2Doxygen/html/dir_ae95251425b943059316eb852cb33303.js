var dir_ae95251425b943059316eb852cb33303 =
[
    [ "build", "dir_4a30bed88161d561d5429603a764addc.html", "dir_4a30bed88161d561d5429603a764addc" ],
    [ "nbproject", "dir_4d6ccc6bf7d54fbe19d69414d542b03f.html", "dir_4d6ccc6bf7d54fbe19d69414d542b03f" ],
    [ ".dep.inc", "_8dep_8inc.html", null ],
    [ "Board.cpp", "_board_8cpp.html", null ],
    [ "Board.h", "_board_8h.html", "_board_8h" ],
    [ "Deck.cpp", "_deck_8cpp.html", null ],
    [ "Deck.h", "_deck_8h.html", "_deck_8h" ],
    [ "Game.cpp", "_game_8cpp.html", null ],
    [ "Game.h", "_game_8h.html", "_game_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "Players.cpp", "_players_8cpp.html", null ],
    [ "Players.h", "_players_8h.html", "_players_8h" ]
];