var annotated_dup =
[
    [ "Board", "class_board.html", "class_board" ],
    [ "Deck", "class_deck.html", "class_deck" ],
    [ "Game", "class_game.html", "class_game" ],
    [ "Players", "class_players.html", "class_players" ]
];