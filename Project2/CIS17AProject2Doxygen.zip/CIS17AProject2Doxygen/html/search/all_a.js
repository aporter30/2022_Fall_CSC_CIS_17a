var searchData=
[
  ['removecolor_0',['removeColor',['../class_game.html#a9a94efa6960b956b3614d47d8a59b96b',1,'Game']]],
  ['reshuffle_1',['reshuffle',['../class_deck.html#a8dbaacaddef573b9488fffab36dd4063',1,'Deck']]]
];
