var searchData=
[
  ['convertcardcolor_0',['convertCardColor',['../class_game.html#af9a554e9f1897d63c3b42807a2c690b1',1,'Game']]]
];
