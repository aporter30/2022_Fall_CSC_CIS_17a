var searchData=
[
  ['winner_0',['winner',['../class_board.html#a9faf754be2ac7a93b8ddf976d60bc501',1,'Board::winner()'],['../class_game.html#a792ac4d0e2e6bc5ae70b3236b7d324a2',1,'Game::winner()']]]
];
