var class_game =
[
    [ "Game", "class_game.html#a60c1fa3b6b58c7cb29a59d79b1500753", null ],
    [ "~Game", "class_game.html#ae3d112ca6e0e55150d2fdbc704474530", null ],
    [ "convertCardColor", "class_game.html#af9a554e9f1897d63c3b42807a2c690b1", null ],
    [ "dos", "class_game.html#a09e7f3df4b119415e3b3cc5a042fb571", null ],
    [ "getWinnerPlayer", "class_game.html#adf36df7eb11935bbefccfecfc2967b55", null ],
    [ "initGame", "class_game.html#a8abdf6e8b4c45c2c6b40f728fce376c8", null ],
    [ "outOfCards", "class_game.html#a92bae1a4bfe98067ea6a118c2519f58a", null ],
    [ "outputTurn", "class_game.html#a75d66a101e593b7fff1dd6cd1f84886b", null ],
    [ "playerTurn", "class_game.html#ab4bd639d87e65757e2ac1061ee8f1a64", null ],
    [ "pressAnyKey", "class_game.html#a80d5b7baa9729c196551e78031d2c5ba", null ],
    [ "removeColor", "class_game.html#a9a94efa6960b956b3614d47d8a59b96b", null ],
    [ "winner", "class_game.html#a792ac4d0e2e6bc5ae70b3236b7d324a2", null ]
];