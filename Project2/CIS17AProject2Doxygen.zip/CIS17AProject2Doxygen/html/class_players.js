var class_players =
[
    [ "Players", "class_players.html#a3ff1a0488140a54cc4e355716b9bef9d", null ],
    [ "~Players", "class_players.html#a550b03902064fa337ccf9f9f67b01d88", null ],
    [ "getColorTaken", "class_players.html#ab9d1e6dbf366364a4c3374605bc2fec9", null ],
    [ "getLocationCol", "class_players.html#ae3c0a80f215fe335f35849914c222088", null ],
    [ "getLocationNum", "class_players.html#abab6d5e4557eac0de13530b72c5edaa4", null ],
    [ "getPlayer", "class_players.html#a20ab7fff9e3a680e9230260574fe865b", null ],
    [ "getPlayerVal", "class_players.html#a75ebb9113fa6214b5923878fe18acd4c", null ],
    [ "setActivePlayer", "class_players.html#ad39e7c09caed8ec67e7aff8da302309a", null ],
    [ "setLocation", "class_players.html#ab8cf7207e21dc0b19e8bc1ef545a9f43", null ],
    [ "setLocationColor", "class_players.html#a9c52a28f2ee048f2b67fee765550cb52", null ],
    [ "setLocationNumber", "class_players.html#a9dcf82e52b14dfc68a2a8ee54d1f7ca7", null ],
    [ "setPlayer", "class_players.html#a3847d0926f52812e1e10828ce7de7e81", null ]
];