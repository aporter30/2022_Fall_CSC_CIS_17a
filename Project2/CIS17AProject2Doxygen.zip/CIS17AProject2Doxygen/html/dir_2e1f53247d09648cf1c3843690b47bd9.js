var dir_2e1f53247d09648cf1c3843690b47bd9 =
[
    [ "Board.o.d", "_board_8o_8d.html", null ],
    [ "Deck.o.d", "_deck_8o_8d.html", null ],
    [ "Game.o.d", "_game_8o_8d.html", null ],
    [ "main.o.d", "main_8o_8d.html", null ],
    [ "Players.o.d", "_players_8o_8d.html", null ]
];