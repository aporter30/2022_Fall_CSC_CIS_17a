var class_board =
[
    [ "Board", "class_board.html#a9ee491d4fea680cf69b033374a9fdfcb", null ],
    [ "~Board", "class_board.html#af73f45730119a1fd8f6670f53f959e68", null ],
    [ "doub", "class_board.html#aa670af9b76f802940848168e6c448ea1", null ],
    [ "getboardSize", "class_board.html#a89c886a5bb5ca1101a0a8c3a61d9d88f", null ],
    [ "getCastleDistance", "class_board.html#aa7a613727dcd98f79597af78ef190395", null ],
    [ "getLocation", "class_board.html#a1e0e9c978575f9fcc3cc5987cc22cb3d", null ],
    [ "ifSpecialCard", "class_board.html#a2af0a5e6a1e5a9c1ed15557d738a0411", null ],
    [ "outputBoard", "class_board.html#a528bf4e6e604b0484c7a6ad7445de65e", null ],
    [ "setBoard", "class_board.html#a6c3286232341c7eb810dc08b90bbbf37", null ],
    [ "setSpecialCards", "class_board.html#ae01add2944e71fc86d578bbd604e24d9", null ],
    [ "sing", "class_board.html#ad8c5770af265747d176c232fcac8c560", null ],
    [ "winner", "class_board.html#a9faf754be2ac7a93b8ddf976d60bc501", null ]
];